#pragma once

namespace sets {

class SettingsBase;

extern SettingsBase* thisSettings;

}  // namespace sets