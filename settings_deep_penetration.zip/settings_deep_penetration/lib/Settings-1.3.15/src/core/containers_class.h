#pragma once
#include <Arduino.h>

namespace sets {
class BasicContainer;
}