#pragma once
#include <inttypes.h>

namespace sets {

enum class TMode : uint8_t {
    Single,
    All,
    Mask,
};

}  // namespace sets
