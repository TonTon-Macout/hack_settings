#pragma once
#include <Arduino.h>
const char  mystyle[] PROGMEM = R"rawliteral(


@font-face {
  font-family: 'dot';
  src: url('dot.woff2') format('woff2')
}
.nav {
  font-family: "dot", sans-serif;
  font-optical-sizing: auto;
  font-weight: 500;
  font-style: bold;
  margin-left: 10px;
  filter: brightness(0.8) grayscale(1);
}
/* ============================================== */


.label {
    writing-mode: vertical-lr;
    font-family: "dot",Verdana,sans-serif;/* Tiny5 */
    font-weight: 900;
    text-orientation: upright; 
    font-size: calc(var(--size) * 0.6);
    color: var(--accent);
    display: flex;
    align-items: center; 
    justify-content: center; 
    border-right: 3px solid var(--accent);
    padding-right: 4px;
    padding: 10px 4px 10px 10px;
    margin-left: -4px;
    background-color: #27272f;
  }
.page:first-of-type > .widget:first-of-type {
    display: flex;
    flex-direction: column;
    background-color: #000000;
     overflow: hidden; 
    padding: 0;
    justify-content: center;
    align-items: flex-start;
  }
  .page:first-of-type > .widget:first-of-type > div:first-of-type {
    margin: 0 !important;
  }
:root {
    --size: 14px;
    --hue: 100deg;
    --saturation: 85%;
    --light: 70%;
    --theme-clock: hsl(var(--hue) var(--saturation) var(--light));
    --transition: box-shadow;
    --transition-easing: cubic-bezier(0.11, -0.13, 1, -0.54);
    --transition-timing: 0.6s;
  }
.clock {
    --saturation: 85%;
    --light: 70%;
    --theme-clock: var(--accent);

    position: relative;
    width: calc(var(--size) * 33);
    height: calc(var(--size) * 7);

  }
.clock .light span {
    --color: rgb(255 255 255 / 100%);
    z-index: 2;
    opacity: 0.5;
    filter: blur(1px);
  }
.clock span {
    --color: var(--theme-clock);
    position: absolute;
    width: calc(var(--size) - 2px);
    height: calc(var(--size) - 2px);
    top: calc(var(--size) * 1);
    left: calc(var(--size) * 1);
    border-radius: 0px;
    box-shadow: inset 0 0 0 var(--size) var(--color);
    transition: box-shadow var(--transition-timing) var(--transition-easing);
  }
.clock span:nth-child(2) { left: calc(var(--size) * 6);  }
.clock span:nth-child(3) { left: calc(var(--size) * 12); }
.clock span:nth-child(4) { left: calc(var(--size) * 17); }
.clock span:nth-child(5) { left: calc(var(--size) * 23); }
.clock span:nth-child(6) { left: calc(var(--size) * 28); }

.containerDay {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    background-color: black;
    border-radius: 10px;
    margin: -4px 0px 0px -4px;
    border-top-left-radius: 0;
    overflow: hidden;
  }
  
  .sidebarDay {
    /* border-right: 3px solid var(--accent); */
    border-right: 3px solid var(--accent);
    /* padding-right: 4px; */
    padding: 0px 0px 0px 19px;
    background-color: #27272f;
  }
  
  .day {
    font-family: "dot", sans-serif;
    color: var(--accent);
    padding-left: 15px;
    padding-bottom: 8px;
    filter: brightness(1.3);
  }

  .widget:has(+ .errorTime) {
    border-bottom-right-radius: 0;
}
.errorTime{
margin: -6px 10px 10px 34px;
padding: 6px 10px;
font-size: 13px;
background-color: #610000;
border-radius: 0 0 10px 10px;
width: fit-content;
margin-left: auto;
}
/* ============================================== */




.HR {
  background-color: var(--back);
  margin: -12px -10px;
  padding: 0px 10px;
  display: flex;
  height: 14px;
}

div.main > div.main_col >div.page> div.buttons>.button:nth-child(1) {
  border-radius: 10px 0 0 10px;
  border-right: solid 2px var(--back);
}
body > div.main > div.main_col >div.page> div.buttons {
  padding: 6px 0px;
  margin: 35px 11px 6px 11px;
}
div.main > div.main_col >div.page> div.buttons>.button:nth-child(2) {
  border-radius: 0px 10px 10px 0px;
  border-left: solid 2px var(--back);
}
body > div.main > div.main_col >div.page> div.buttons>.button {
  margin: 0px;
  width: 100%;
  padding: 10px 10px;
}


.log { 
  max-height: 700px;
}

.group_row > .widget:nth-of-type(2):has(.widget_label) {
 border-left: 2px solid var(--back);
 padding-left: 10px;
}

.group_title span {
 color: var(--accent);
 font-weight: 600;
 margin-left: 10px;
    filter: brightness(0.8);
}

.theme_light:not(.theme_dark) > div.main > div.main_col >div.page> div.buttons>.button:nth-child(2) {
    border-radius: 0px 10px 10px 0px; 
    border-left: solid 2px  var(--back);
} 
.theme_light:not(.theme_dark) > div.main > div.main_col >div.page> div.buttons>.button:nth-child(1) {
    border-radius: 10px 0 0 10px; 
    border-right: solid 2px var(--back);
} 


.page>.row>.group_row:last-of-type {
       box-shadow: none;
       margin: 0 10px;
       background: transparent;
       justify-content: center;
       color: #52b737;
}


/* ==================================== */
.help_butt {
    border: 0;
    background-color: var(--accent);
    border-radius: 20px;
    height: 30px;
    color: #ffffff;
    font-weight: 700;
    font-size: 14px;
    padding-left: 14px;
    padding-right: 14px;
    font-family: unset;
    cursor: pointer;
}
.help_butt_main {
    border: 0;
    background-color: var(--accent);
    border-radius: 20px;
    height: 30px;
    width: 30px;
    color: #ffffff;
    font-weight: 700;
    font-size: 21px;
    font-family: unset;
    cursor: pointer;
}
.popupHelp {
  max-width: 550px;
  border: solid 0px rgb(0, 89, 133);
  text-align: center;
  color: #272727;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #f4f4f4;
  padding: 10px;
  box-shadow: rgb(0 55 81) 0px 0px 8px 5px, rgb(0 89 133) 0px 0px 0px 60px;
  z-index: 10000001;
  width: 88%;
  height: 93%;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.popupHelp-header {
  font-size: 24px;
  font-weight: bold;
  padding-bottom: 10px;
  border-bottom: 1px solid #ddd;
  color: rgb(0, 89, 133);
}

.popupHelp-body {
  flex: 1;
  padding: 5px;
  overflow-y: auto;
  font-size: 15px;
  text-align: left;
}
.popupHelp-body ul {
  padding-inline-start: 20px;
  text-align: left;
}
.popupHelp-body h5  {/* Ð¿Ð¾ Ñ†ÐµÐ½Ñ‚Ñ€Ñƒ ÑÑ€ÐµÐ´Ð½Ð¸Ð¹ */
  text-align: center;
  margin-left: 10px;
  color: rgb(0, 89, 133);
  font-size: 21px;
}
.popupHelp-body h4  {  /* Ð½ÐµÐ±Ð¾Ð»ÑŒÑˆÐ¾Ð¹ ÑÐ²ÐµÑ‚Ð»Ð¾ÑÐ¸Ð½Ð¸Ð¹ Ð·Ð°Ð³Ð¾Ð»Ð¾Ð²Ð¾Ðº  */
  margin-left: 10px;
  color: rgb(47, 116, 152);
  font-size: 15px;
}
.popupHelp-body h3  { 
  text-align: left ; /* ÑÐ»ÐµÐ²Ð° ÑÑ€ÐµÐ´Ð½Ð¸Ð¹ */
  margin-left: 10px;
  color: rgb(0, 89, 133);
  font-size: 21px;
}
.popupHelp-footer {
  padding: 0px;
  border-top: 1px solid #ddd;
  text-align: center;
}

.popupHelp-close-btn {
  margin-top: 10px;
  background-color: rgb(0, 89, 133);
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  border-radius: 5px;
}
ol.main_pop {
  counter-reset: li; /* Ð¡Ð±Ñ€Ð°ÑÑ‹Ð²Ð°ÐµÐ¼ ÑÑ‡Ñ‘Ñ‚Ñ‡Ð¸Ðº Ð´Ð»Ñ <ol> */
  list-style: none;
  padding: 0;
}

ol.main_pop li {
  display: flex; 
  align-items: center;
  margin: 8px 0; 
}

ol.main_pop a {
  border-radius: 6px;
  align-items: center; /* Ð¦ÐµÐ½Ñ‚Ñ€Ð¸Ñ€ÑƒÐµÐ¼ Ñ‚ÐµÐºÑÑ‚ Ð² ÑÑÑ‹Ð»ÐºÐµ */
  padding: 10px 18px 10px 25px;
  margin-left: 10px; /* ÐžÑ‚ÑÑ‚ÑƒÐ¿ Ð¼ÐµÐ¶Ð´Ñƒ <b> Ð¸ <a> */
  background: #ffffff;
  font-size: 18px;
  color: #005985;
  text-decoration: none;
  transition: all 1s ease-out;
  box-shadow: 0 0 10px var(--shadow);
  width: 100%; /* Ð¨Ð¸Ñ€Ð¸Ð½Ð° ÑÑÑ‹Ð»ÐºÐ¸ */
}

ol.main_pop a:hover {
  background: #005985;
  color: white;
}

ol.main_pop li a:before {
  padding: 10px 15px;
  margin: -10px 0;
  content: counter(li);
  counter-increment: li;
  position: relative;
  left: -35px;
  background: #005985;
  text-align: center;
  font-weight: bold;
  color: #f4f4f4;
  border-top-left-radius:6px;
  border-bottom-left-radius:6px;
}

/* ==================================== */







)rawliteral";