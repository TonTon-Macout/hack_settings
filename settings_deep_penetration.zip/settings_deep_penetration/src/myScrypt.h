#pragma once
#include <Arduino.h>
const uint8_t myscript[] PROGMEM = R"rawliteral(



const DEBUG_LEVEL = 'off'; // all, errors, off

class Clock {
  constructor() {
    this.observer = null;
    this.currentTime = null; // Текущее время
    this.currentDate = null; // Текущая дата
    this.currentDay = null; // Текущее число
    this.currentWeekday = null; // Текущий день недели
    this.currentMonth = null; // Текущий месяц
    this.timerId = null; // ID для setInterval
    this.timeSyncTimerId = null; // таймер проверки времени
    this.checkTime = null; // сообщать ли о неправильном времени
    this.nb = [
      // 0
      "inset 0 0 0 var(--size) var(--color), 0px var(--size) var(--color), 0px calc(var(--size) * 2) var(--color), 0px calc(var(--size) * 3) var(--color), 0px calc(var(--size) * 4) var(--color), var(--size) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), calc(var(--size) * 3) var(--size) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color), var(--size) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color)",
      // 1
      "inset 0 0 0 var(--size) rgb(0 0 0 / 0), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 1) var(--size) var(--color), calc(var(--size) * 2) var(--size) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 3) var(--color), calc(var(--size) * 1) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color)",
      // 2
      "inset 0 0 0 var(--size) var(--color), var(--size) 0px var(--color), calc(var(--size) * 2) 0px var(--color), calc(var(--size) * 3) 0px var(--color), calc(var(--size) * 3) var(--size) var(--color), 0 calc(var(--size) * 2) var(--color), var(--size) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), 0 calc(var(--size) * 3) var(--color), 0 calc(var(--size) * 4) var(--color), var(--size) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color)",
      // 3
      "inset 0 0 0 var(--size) var(--color), 0px calc(var(--size) * 4) var(--color), var(--size) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), calc(var(--size) * 3) var(--size) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), var(--size) calc(var(--size) * 2) var(--color), 0 calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color), var(--size) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color)",
      // 4
      "inset 0 0 0 var(--size) var(--color), calc(var(--size)* 3) 0 var(--color), calc(var(--size)* 3) var(--size) var(--color), calc(var(--size)* 3) calc(var(--size) * 2) var(--color), calc(var(--size)* 2) calc(var(--size) * 2) var(--color), var(--size) calc(var(--size) * 2) var(--color), 0 calc(var(--size) * 2) var(--color), 0 var(--size) var(--color), calc(var(--size)* 3) calc(var(--size) * 3) var(--color), calc(var(--size)* 3) calc(var(--size) * 4) var(--color)",
      // 5
      "inset 0 0 0 var(--size) var(--color), 0px var(--size) var(--color), var(--size) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), 0 calc(var(--size) * 2) var(--color), var(--size) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color), var(--size) calc(var(--size) * 4) var(--color), 0 calc(var(--size) * 4) var(--color)",
      // 6
      "inset 0 0 0 var(--size) var(--color), 0 0 var(--color), calc(var(--size) * 1) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), 0 var(--size) var(--color), 0 calc(var(--size) * 2) var(--color), calc(var(--size) * 1) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), 0 calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), 0 calc(var(--size) * 4) var(--color), calc(var(--size) * 1) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color)",
      // 7
      "inset 0 0 0 var(--size) var(--color), calc(var(--size) * 3) 0 var(--color), calc(var(--size) * 2) 0 var(--color), var(--size) 0 var(--color), calc(var(--size) * 3) var(--size) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color)",
      // 8
      "inset 0 0 0 var(--size) var(--color), 0px var(--size) var(--color), 0px calc(var(--size) * 2) var(--color), 0px calc(var(--size) * 3) var(--color), 0px calc(var(--size) * 4) var(--color), var(--size) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), calc(var(--size) * 3) var(--size) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), var(--size) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color), var(--size) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color)",
      // 9
      "inset 0 0 0 var(--size) var(--color), 0 0 var(--color), calc(var(--size) * 1) 0 var(--color), calc(var(--size) * 2) 0 var(--color), calc(var(--size) * 3) 0 var(--color), 0 var(--size) var(--color), calc(var(--size) * 3) var(--size) var(--color), 0 calc(var(--size) * 2) var(--color), calc(var(--size) * 1) calc(var(--size) * 2) var(--color), calc(var(--size) * 2) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 2) var(--color), calc(var(--size) * 3) calc(var(--size) * 3) var(--color), 0 calc(var(--size) * 4) var(--color), calc(var(--size) * 1) calc(var(--size) * 4) var(--color), calc(var(--size) * 2) calc(var(--size) * 4) var(--color), calc(var(--size) * 3) calc(var(--size) * 4) var(--color)"
    ];
    this.init();
  }

  log(message, isError = false) {
    if (DEBUG_LEVEL === 'off') return;
    if (DEBUG_LEVEL === 'errors' && !isError) return;

    const timestamp = new Date().toLocaleTimeString('ru-RU');
    const timestampmsecond = new Date().toLocaleTimeString('ru-RU', { fractionalSecondDigits: 3 });
    
    const logType = isError ? 'ОШИБКА' : 'ИНФО';
    const separator = '══════════════════════════════════════';
    const formattedMessage = `
${separator}
🕒 Время: ${timestamp}:${timestampmsecond}
💬 ${logType}: ${message}
${separator}
`;

    if (isError) {
      console.error(formattedMessage);
    } else {
      console.log(formattedMessage);
    }
  }

  parseTime(dataWidget) {
    const timeStr = dataWidget.getAttribute('data-time');
    const dateStr = dataWidget.getAttribute('data-date');
    const weekdayStr = dataWidget.getAttribute('data-weekday');
    const monthStr = dataWidget.getAttribute('data-month');
    const checkTimeStr = dataWidget.getAttribute('data-checkTime');

    const [hours, minutes, seconds] = timeStr ? timeStr.split(':').map(Number) : [null, null, null];
    if (isNaN(hours) || isNaN(minutes) || isNaN(seconds)) {
      this.log(`Неверный формат времени: ${timeStr}`, true);
      return null;
    }
    const checktime = checkTimeStr ? checkTimeStr : null;
    if (!checktime) {
      this.log('Атрибут data-checkTime не найден', true);
    }
    const date = dateStr ? dateStr : null;
    if (!dateStr) {
      this.log('Атрибут data-date не найден', true);
    }
    const weekday = weekdayStr ? weekdayStr : null;
    if (!weekdayStr) {
      this.log('Атрибут data-weekday не найден', true);
    }
    const month = monthStr ? monthStr : null;
    if (!monthStr) {
      this.log('Атрибут data-month не найден', true);
    }

    return { hours, minutes, seconds, date, weekday, month, checktime };
  }

  padNumber(num) {
    const padded = num.toString().padStart(2, '0');
    this.log(`Добавление ведущих нулей к числу ${num}: ${padded}`);
    return padded;
  }

  incrementTime() {
    if (!this.currentTime) return;
    let { hours, minutes, seconds } = this.currentTime;
    seconds++;
    if (seconds >= 60) {
      seconds = 0;
      minutes++;
      if (minutes >= 60) {
        minutes = 0;
        hours++;
        if (hours >= 24) {
          hours = 0;
        }
      }
    }
    this.currentTime = { hours, minutes, seconds, date: this.currentDate, weekday: this.currentWeekday, month: this.currentMonth };
    this.log(`Время увеличено до ${this.padNumber(hours)}:${this.padNumber(minutes)}:${this.padNumber(seconds)}`);
  }

  updateClockSize(clockWidget) {
    const clockElement = clockWidget.querySelector('.clock');
    if (clockElement) {
      const widget = clockElement.closest('.widget');
      if (widget) {
        const widgetWidth = widget.offsetWidth;
        const size = widgetWidth / 33 - 1;
        clockElement.style.setProperty('--size', `${size}px`);
        this.log(`Часы: Установлен --size = ${size.toFixed(2)}px (ширина виджета: ${widgetWidth}px)`);
      } else {
        this.log('Часы: Контейнер .widget не найден, используется --size: 12px', true);
        clockElement.style.setProperty('--size', '12px');
      }
    }
  }

  startClockTimer(clockElement) {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.log('Предыдущий таймер очищен');
    }
    this.timerId = setInterval(() => {
      this.incrementTime();
      this.updateClockDisplay(clockElement, this.currentTime);
    }, 1000);
    this.log('Таймер часов запущен');
  }

  checkTimeSync(widgetDiv) {
    if (!this.currentTime) {
      this.log('Текущее время (currentTime) недоступно для сравнения', true);
      return;
    }
    if (this.checkTime == 0) return;

    const now = new Date();
    const browserHours = now.getHours();
    const browserMinutes = now.getMinutes();
    const browserSeconds = now.getSeconds();

    const { hours, minutes, seconds } = this.currentTime;
    const widgetTimeInSeconds = hours * 3600 + minutes * 60 + seconds;
    const browserTimeInSeconds = browserHours * 3600 + browserMinutes * 60 + browserSeconds;
    const timeDifference = Math.abs(widgetTimeInSeconds - browserTimeInSeconds);

    const existingError = widgetDiv.parentElement?.querySelector('.errorTime');
    if (timeDifference > 60) {
      if (!existingError) {
        const widgetErr = document.createElement('div');
        widgetErr.className = 'errorTime';
        widgetErr.innerHTML = `время не актуально`;
        widgetDiv.insertAdjacentElement('afterend', widgetErr);
        this.log(`Добавлен элемент errorTime: Время виджета (${hours}:${minutes}:${seconds}) отличается от времени браузера (${browserHours}:${browserMinutes}:${browserSeconds}) на ${timeDifference} секунд`, true);
      }
    } else {
      if (existingError) {
        existingError.remove();
        this.log(`Удален элемент errorTime: Время виджета (${hours}:${minutes}:${seconds}) теперь в пределах 1 минуты от времени браузера (${browserHours}:${browserMinutes}:${browserSeconds})`);
      }
    }

    this.log(`Проверка синхронизации времени: Разница составляет ${timeDifference} секунд`);
  }

  createClockWidget() {
    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'widget';
    widgetDiv.innerHTML = `
      <div style="margin: 5px 0px; display: flex; align-items: center;">
        <div class="label">GLUONiCA</div>
        <div class="clock">
          <div class="light">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
          </div>
          <div>
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>
      <div class="containerDay">
        <div class="sidebarDay">&nbsp</div>
        <div class="day">${this.currentDay} ${this.currentMonth} ${this.currentWeekday}</div>
      </div>
    `;
    this.log('Виджет часов создан с меткой GLUONiCA (видимый)');
    return widgetDiv;
  }

  startTimeSyncCheck(widgetDiv) {
    if (this.timeSyncTimerId) {
      clearInterval(this.timeSyncTimerId);
      this.log('Предыдущий таймер синхронизации времени очищен');
    }
    this.timeSyncTimerId = setInterval(() => {
      this.checkTimeSync(widgetDiv);
    }, 5000);
    this.log('Таймер проверки синхронизации времени запущен');
  }

  updateClockDisplay(clockElement, timeData) {
    if (!timeData) return;
    const timeString = `${this.padNumber(timeData.hours)}:${this.padNumber(timeData.minutes)}:${this.padNumber(timeData.seconds)}`;
    const timeArray = timeString.split('').filter(v => v !== ':');

    const divs = clockElement.querySelectorAll('div');
    if (divs.length < 2) {
      this.log('Недостаточно элементов div в виджете часов', true);
      return;
    }

    timeArray.forEach((digit, i) => {
      for (let x = 0; x < divs.length; x++) {
        const cell = divs[x].querySelector(`span:nth-child(${i + 1})`);
        if (cell) {
          const shadowValue = this.nb[parseInt(digit)];
          cell.style.boxShadow = shadowValue;
        } else {
          this.log(`Часы, Цифра ${i + 1}, Ячейка ${x + 1}: Элемент span не найден`, true);
        }
      }
    });

    const dayElement = clockElement.closest('.widget').querySelector('.day');
    if (dayElement && timeData.weekday && timeData.date && timeData.month) {
      const day = parseInt(timeData.date.split('.')[0], 10);
      if (!isNaN(day)) {
        dayElement.textContent = `${day} ${timeData.month} ${timeData.weekday}`;
        this.log(`Элемент дня обновлен до ${day} ${timeData.month} ${timeData.weekday}`);
      } else {
        this.log('Неверный формат даты для извлечения дня', true);
        dayElement.textContent = timeData.weekday;
      }
    } else {
      this.log('Элемент дня или необходимые данные (день недели, дата, месяц) не найдены', true);
    }

    this.log(`Циферблат обновлен до ${timeString}`);
  }

  setupObserver() {
    const targetNode = document.querySelector('body');
    if (!targetNode) {
      this.log('Элемент body не найден для наблюдателя', true);
      return;
    }

    this.observer = new MutationObserver((mutations) => {
      let shouldReinitialize = false;
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches('.page') || 
                node.querySelector('.page .widget > div > .clock-data[data-time]')) {
              shouldReinitialize = true;
            }
          }
        });

        if (mutation.type === 'attributes' && 
            (mutation.target.matches('.clock-data[data-time]') || 
             mutation.target.matches('.page'))) {
          const pageElement = mutation.target.matches('.page') 
            ? mutation.target 
            : mutation.target.closest('.page');
          
          if (pageElement && getComputedStyle(pageElement).display === 'block') {
            const dataWidget = pageElement.querySelector('.widget > div > .clock-data[data-time]');
            if (dataWidget) {
              shouldReinitialize = true;
            }
          }
        }
      });

      if (shouldReinitialize) {
        const pageElement = document.querySelector('.page');
        if (pageElement && !pageElement.dataset.clockInitialized) {
          this.initClocks();
          pageElement.dataset.clockInitialized = 'true';
          this.log('Обнаружена новая страница или данные часов, часы переинициализированы');
        }
      }
    });

    this.observer.observe(targetNode, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['data-time', 'data-date', 'data-weekday', 'data-month', 'style']
    });
    this.log('Наблюдатель за изменениями DOM инициализирован');
  }

  initClocks() {
    const pageElement = document.querySelector('.page');
    if (!pageElement) {
      this.log('Элемент page не найден', true);
      return;
    }
  
    if (getComputedStyle(pageElement).display !== 'block') {
      this.log('Элемент page не имеет display: block', true);
      return;
    }
  
    const dataWidget = pageElement.querySelector('.widget > div > .clock-data[data-time]');
    if (!dataWidget) {
      this.log('Элемент clock-data не найден в виджете', true);
      return;
    }
  
    const dataWidgetParent = dataWidget.closest('.widget');
    if (!dataWidgetParent) {
      this.log('Родительский виджет для clock-data не найден', true);
      return;
    }
  
    dataWidgetParent.style.display = 'none';
    this.log('Установлен display: none для виджета с clock-data');
  
    const firstWidget = pageElement.querySelector('.widget');
    if (!firstWidget) {
      this.log('Элемент widget не найден на странице', true);
      return;
    }
  
    const timeData = this.parseTime(dataWidget);
    if (!timeData) {
      this.log('Не удалось разобрать данные времени', true);
      return;
    }
  
    this.currentTime = { hours: timeData.hours, minutes: timeData.minutes, seconds: timeData.seconds };
    this.currentDate = timeData.date;
    this.currentDay = timeData.date ? parseInt(timeData.date.split('.')[0], 10) : null;
    this.currentWeekday = timeData.weekday;
    this.currentMonth = timeData.month;
    this.checkTime = timeData.checktime;
  
    if (isNaN(this.currentDay)) {
      this.log(`Неверный формат даты: ${timeData.date}`, true);
    } else {
      this.log(`Извлечен день из даты: ${this.currentDay}`);
    }
  
    const widgets = pageElement.querySelectorAll('.widget');
    for (const widget of widgets) {
      if (widget.querySelector('.clock')) {
        const clockElement = widget.querySelector('.clock');
        this.updateClockSize(widget);
        this.updateClockDisplay(clockElement, timeData);
        this.startClockTimer(clockElement);
        this.startTimeSyncCheck(widget);
        widget.style.display = '';
        this.log('Виджет часов уже существует, обновлен и обеспечена видимость');
  
        if (this.currentTime && this.checkTime !== '0') {
          const now = new Date();
          const browserHours = now.getHours();
          const browserMinutes = now.getMinutes();
          const browserSeconds = now.getSeconds();
          const browserDate = `${now.getDate().toString().padStart(2, '0')}.${(now.getMonth() + 1).toString().padStart(2, '0')}.${now.getFullYear()}`;
  
          const { hours, minutes, seconds } = this.currentTime;
          const widgetTimeInSeconds = hours * 3600 + minutes * 60 + seconds;
          const browserTimeInSeconds = browserHours * 3600 + browserMinutes * 60 + browserSeconds;
          const timeDifference = Math.abs(widgetTimeInSeconds - browserTimeInSeconds);
  
          // Проверка на существующий элемент errorTime
          const existingError = widget.parentElement?.querySelector('.errorTime');
          if (this.currentDate !== browserDate || timeDifference > 60) {
            if (!existingError) {
              const widgetErr = document.createElement('div');
              widgetErr.className = 'errorTime';
              // Объединяем сообщения, давая приоритет ошибке даты
              widgetErr.innerHTML = this.currentDate !== browserDate
                ? `дата в часах не совпадает с датой в браузере`
                : `время в часах не совпадает с временем в браузере`;
              widget.insertAdjacentElement('afterend', widgetErr);
              this.log(`Добавлен элемент errorTime при инициализации: ${
                this.currentDate !== browserDate
                  ? `Дата виджета (${this.currentDate}) отличается от даты браузера (${browserDate})`
                  : `Время виджета (${hours}:${minutes}:${seconds}) отличается от времени браузера (${browserHours}:${browserMinutes}:${browserSeconds}) на ${timeDifference} секунд`
              }`, true);
            }
          } else {
            if (existingError) {
              existingError.remove();
              this.log('Удален элемент errorTime: Время и дата виджета в пределах нормы');
            }
            this.log(`Проверка времени и даты пройдена при инициализации: Время виджета (${hours}:${minutes}:${seconds}) и дата (${this.currentDate}) в пределах 1 минуты и совпадают с временем (${browserHours}:${browserMinutes}:${browserSeconds}) и датой браузера (${browserDate})`);
          }
        }
        return;
      }
    }
  
    const clockWidget = this.createClockWidget();
    pageElement.insertBefore(clockWidget, firstWidget);
    const clockElement = clockWidget.querySelector('.clock');
    this.updateClockSize(clockWidget);
    this.updateClockDisplay(clockElement, timeData);
    this.startClockTimer(clockElement);
    this.startTimeSyncCheck(clockWidget);
    this.log('Создан новый виджет часов с меткой GLUONiCA, инициализирован и виден');
  
    if (this.currentTime && this.checkTime !== '0') {
      const now = new Date();
      const browserHours = now.getHours();
      const browserMinutes = now.getMinutes();
      const browserSeconds = now.getSeconds();
      const browserDate = `${now.getDate().toString().padStart(2, '0')}.${(now.getMonth() + 1).toString().padStart(2, '0')}.${now.getFullYear()}`;
  
      const { hours, minutes, seconds } = this.currentTime;
      const widgetTimeInSeconds = hours * 3600 + minutes * 60 + seconds;
      const browserTimeInSeconds = browserHours * 3600 + browserMinutes * 60 + browserSeconds;
      const timeDifference = Math.abs(widgetTimeInSeconds - browserTimeInSeconds);
  
      // Проверка на существующий элемент errorTime
      const existingError = clockWidget.parentElement?.querySelector('.errorTime');
      if (this.currentDate !== browserDate || timeDifference > 60) {
        if (!existingError) {
          const widgetErr = document.createElement('div');
          widgetErr.className = 'errorTime';
          // Объединяем сообщения, давая приоритет ошибке даты
          widgetErr.innerHTML = this.currentDate !== browserDate
            ? `дата в часах не совпадает с датой в браузере`
            : `время в часах не совпадает с временем в браузере`;
          clockWidget.insertAdjacentElement('afterend', widgetErr);
          this.log(`Добавлен элемент errorTime при инициализации: ${
            this.currentDate !== browserDate
              ? `Дата виджета (${this.currentDate}) отличается от даты браузера (${browserDate})`
              : `Время виджета (${hours}:${minutes}:${seconds}) отличается от времени браузера (${browserHours}:${browserMinutes}:${browserSeconds}) на ${timeDifference} секунд`
          }`, true);
        }
      } else {
        if (existingError) {
          existingError.remove();
          this.log('Удален элемент errorTime: Время и дата виджета в пределах нормы');
        }
        this.log(`Проверка времени и даты пройдена при инициализации: Время виджета (${hours}:${minutes}:${seconds}) и дата (${this.currentDate}) в пределах 1 минуты и совпадают с временем (${browserHours}:${browserMinutes}:${browserSeconds}) и датой браузера (${browserDate})`);
      }
    }
  }

  init() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.initClocks();
        this.setupObserver();
        window.addEventListener('resize', () => {
          const clockWidget = document.querySelector('.widget:has(.clock)');
          if (clockWidget) {
            this.updateClockSize(clockWidget);
          }
        });
        this.log('Класс часов инициализирован после события DOMContentLoaded');
      });
    } else {
      this.initClocks();
      this.setupObserver();
      window.addEventListener('resize', () => {
        const clockWidget = document.querySelector('.widget:has(.clock)');
        if (clockWidget) {
          this.updateClockSize(clockWidget);
        }
      });
      this.log('Класс часов инициализирован');
    }
  }

  destroy() {
    if (this.observer) {
      this.observer.disconnect();
      this.log('Наблюдатель за изменениями DOM отключен');
    }
    if (this.timerId) {
      clearInterval(this.timerId);
      this.log('Таймер часов очищен');
    }
    if (this.timeSyncTimerId) {
      clearInterval(this.timeSyncTimerId);
      this.log('Таймер проверки синхронизации времени очищен');
    }
    window.removeEventListener('resize', this.updateClockSize);
  }
}

const clock = new Clock();











//===  Скрываем пароль в окне ввода пароля. Б - Безопасность.

const PASSWORD_MASK_ENABLED = true;  // true - скрипт работает, false - полностью отключен
const PASSWORD_DEBUG = false;        // true - логи включены, false - выключены

function applyPasswordMask() {
  // Полное отключение скрипта
  if (!PASSWORD_MASK_ENABLED) return;
  
  // Ищем только dialog_back, который появляется динамически
  const dialogs = document.querySelectorAll('.dialog_back');
  
  if (PASSWORD_DEBUG) {
      console.log(`🔍 Найдено dialog_back: ${dialogs.length}`);
  }
  
  dialogs.forEach(dialog => {
      const label = dialog.querySelector('label');
      if (!label) return;
      
      const labelText = label.textContent.trim().toLowerCase();
      
      if (labelText === 'пароль') {
          const textarea = dialog.querySelector('textarea');
          
          if (textarea) {
              textarea.style.fontFamily = 'text-security-disc';
              textarea.style.webkitTextSecurity = 'disc';
              
              if (PASSWORD_DEBUG) {
                  console.log('✅ Маска пароля применена к диалогу');
              }
          }
      }
  });
}

// Применить к существующим, если скрипт включен
if (PASSWORD_MASK_ENABLED) {
  applyPasswordMask();
}

// Наблюдаем ТОЛЬКО за появлением dialog_back
const observer = new MutationObserver((mutations) => {
  // Полное отключение скрипта
  if (!PASSWORD_MASK_ENABLED) return;
  
  let needsUpdate = false;
  
  mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
          // Проверяем, не появился ли dialog_back
          if (node.nodeType === 1) { // element node
              if (node.matches?.('.dialog_back') || node.querySelector?.('.dialog_back')) {
                  needsUpdate = true;
              }
          }
      });
  });
  
  if (needsUpdate) {
      setTimeout(applyPasswordMask, 50);
  }
});

// Запускаем наблюдатель только если скрипт включен
if (PASSWORD_MASK_ENABLED) {
  observer.observe(document.body, {
      childList: true,
      subtree: true
  });
}
//=========


// кнока  справки ================

function help(contentType = 'main') {
  // Создание элементов
  const popup = document.createElement('div');
  const popupHeader = document.createElement('div');
  const popupBody = document.createElement('div');
  const popupFooter = document.createElement('div');
  const closeButton = document.createElement('button');

  // Присвоение классов
  popup.className = 'popupHelp';
  popupHeader.className = 'popupHelp-header';
  popupBody.className = 'popupHelp-body';
  popupFooter.className = 'popupHelp-footer';
  closeButton.className = 'popupHelp-close-btn';
 
  //const versionElement = document.querySelector('[data-version]');
  //const VERSION = versionElement ? versionElement.dataset.version : '[хз]';
  //const vers = '<span style="color: gray;">версия прошивки: </span></br>' + VERSION ;
  
  // Контент
  popupHeader.textContent = 'Справка';
  switch (contentType.toLowerCase()) {
      
      case 'main':
          popupBody.innerHTML = `
             <!-- <h3>Оглавление</h3> 
              
              <h5>Оглавление</h5>-->
              <ol class = "main_pop">
                  <li><a href="#" onclick="help('help'); return false;">Помогите!</a> </li>
                  <li><a href="#" onclick="help('about'); return false;">О программе</a> </li>
              </ol>
          `;

          break;
      case 'help':
          popupBody.innerHTML = `
              <h3>Помощ в пути!</h3>
              <ul>
                  <li>или нет 🤷</li>
                  <li><b>Известные баги</b>: их нет но есть фичи</li>
              </ul>
          `;
          break;


      case 'about':
              popupBody.innerHTML = `
                 <!-- <h3>О программе:</h3> -->
                  <h4>Собсвтенно программа</h4>
                  </br>
              `;
      break;



          default:
          popupBody.innerHTML = `
              <h3>Ошибка</h3>
              <p>упс...</p>
          `;
          break;
  }

  closeButton.textContent = 'Закрыть';


  popup.style.display = 'flex'; // Показываем попап

  // Обработчик для кнопки закрытия
  closeButton.onclick = function() {
      popup.style.display = 'none'; // Скрываем 
      // Или document.body.removeChild(popup); для полного удаления
  };

  // Сборка попапа
  popupFooter.appendChild(closeButton);
  popup.appendChild(popupHeader);
  popup.appendChild(popupBody);
  popup.appendChild(popupFooter);
  document.body.appendChild(popup);
}
//=========================


)rawliteral";