
#include <Arduino.h>

const bool app = true; // запускать ли точку доступа
#define WIFI_SSID ""
#define WIFI_PASS ""

#ifdef ESP8266
#include <ESP8266WiFi.h>
#else
#include <WiFi.h>
#endif

#include <SettingsGyver.h>
SettingsGyver sett("SETTINGS - DEEP PENETRATION");
sets::Logger logger(2000);

char ssid[25] = WIFI_SSID;
char password[20] = WIFI_PASS;

bool show_setting, timer, process, connected, my_theme = true;
uint8_t mode, dimm;
uint32_t timer_time = 64800;  // время будильника
uint32_t start_mute = 50000;
uint32_t end_mute = 60000;

String get_month(int monthNumber);
String get_month();
int getDaysInMonth(int month, int year);

bool check_time = true;
bool new_year = false;
String timeToString() {
  static unsigned long lastTime = 0;  // для отслеживания последнего вызова
  static int hours = 10;    // начальное значение часов
  static int minutes = 20;  // начальное значение минут
  static int seconds = 22;  // начальное значение секунд
  
  unsigned long currentTime = millis();
  
  // Проверяем, прошел ли 1 секунда (1000 мс)
  if (currentTime - lastTime >= 1000) {
    lastTime = currentTime;  // запоминаем время последнего вызова
    
    seconds++;
    
    if (seconds >= 60) {
      seconds = 0;
      minutes++;
      
      if (minutes >= 60) {
        minutes = 0;
        hours++;
        
        if (hours >= 24) {
          hours = 0;
        }
      }
    }
  }
  
  // Формируем строку с ведущими нулями
  String timeStr = "";
  
  if (hours < 10) timeStr += "0";
  timeStr += hours;
  timeStr += ":";
  
  if (minutes < 10) timeStr += "0";
  timeStr += minutes;
  timeStr += ":";
  
  if (seconds < 10) timeStr += "0";
  timeStr += seconds;
  
  return timeStr;
}
// Функция для получения даты в формате "ДД месяц ГГГГ"
String dateToString() {
  static unsigned long lastTime = 0;
  static int day = 15;      // начальное значение дня
  static int month = 1;     // начальное значение месяца (январь)
  static int year = 2024;   // начальное значение года
  
  unsigned long currentTime = millis();
  
  // Обновляем дату раз в секунду (для теста)
  if (currentTime - lastTime >= 1000) {
    lastTime = currentTime;
    day++;
    
    // Проверяем количество дней в месяце
    int daysInMonth = getDaysInMonth(month, year);
    
    if (day > daysInMonth) {
      day = 1;
      month++;
      
      if (month > 12) {
        month = 1;
        year++;
      }
    }
  }
  
  String dateStr = "";
  
  // Добавляем день с ведущим нулем
  if (day < 10) dateStr += "0";
  dateStr += day;
  dateStr += " ";
  
  // Добавляем название месяца
  dateStr += get_month(month);
  dateStr += " ";
  
  // Добавляем год
  dateStr += year;
  
  return dateStr;
}

// Функция для получения названия дня недели
String get_weekday() {
  static unsigned long lastTime = 0;
  static int weekday = 1;  // 1 - понедельник, 2 - вторник и т.д.
  
  unsigned long currentTime = millis();
  
  // Обновляем день недели раз в секунду
  if (currentTime - lastTime >= 1000) {
    lastTime = currentTime;
    weekday++;
    if (weekday > 7) weekday = 1;
  }
  
  switch(weekday) {
    case 1: return "понедельник";
    case 2: return "вторник";
    case 3: return "среда";
    case 4: return "четверг";
    case 5: return "пятница";
    case 6: return "суббота";
    case 7: return "воскресенье";
    default: return "";
  }
}

// Функция для получения названия месяца по номеру
String get_month(int monthNumber) {
  switch(monthNumber) {
    case 1: return "января";
    case 2: return "февраля";
    case 3: return "марта";
    case 4: return "апреля";
    case 5: return "мая";
    case 6: return "июня";
    case 7: return "июля";
    case 8: return "августа";
    case 9: return "сентября";
    case 10: return "октября";
    case 11: return "ноября";
    case 12: return "декабря";
    default: return "";
  }
}

// Вспомогательная функция для определения количества дней в месяце
int getDaysInMonth(int month, int year) {
  switch(month) {
    case 2: // Февраль
      // Проверка на високосный год
      if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
        return 29;
      } else {
        return 28;
      }
    case 4: case 6: case 9: case 11:
      return 30; // Апрель, июнь, сентябрь, ноябрь
    default:
      return 31; // Остальные месяцы
  }
}

// Перегруженная функция get_month() без параметров
// для обратной совместимости с вашим запросом
String get_month() {
  static unsigned long lastTime = 0;
  static int month = 1;
  
  unsigned long currentTime = millis();
  
  if (currentTime - lastTime >= 1000) {
    lastTime = currentTime;
    month++;
    if (month > 12) month = 1;
  }
  
  return get_month(month);
}


void build(sets::Builder &b) {
    String clockHtml = "<div style=\"display: none;\" class=\"clock-data\" data-time=\"" + (timeToString()) + "\"data-date=\"" + (dateToString()) + "\"data-checkTime=\"" + String(check_time) + "\"data-weekday=\"" + get_weekday() + "\"data-month=\"" + get_month() + "\"data-newyear=\"" + String(new_year) + "\"  ></div>";
    b.HTML(H(timerData), "", clockHtml);

  { sets::Group r(b);
    if (b.Switch("Сверять время с браузером", &check_time)) {
      b.reload();
    }
    if (b.Switch("Ура! Новый Год!", &new_year)) {
      b.reload();
    }
    if (!process) {
      if (b.Button(F("пуск"))) {
        process = !process;
        b.reload();
      }
    } else {
      if (b.Button(F("стоп"))) {
        process = !process;
        b.reload();
      }
    }
  }

  { sets::Group r(b);

    if (b.Select("mode", "0;1;2;3;4;5", &mode))  b.reload();
  }

   b.HTML("", R"raw(<button class="help_butt_main"  type="button"  onclick="help('main')">?</button>)raw"); 
   b.HTML("", R"raw(<button  class="help_butt" type="button"  onclick="help('about')">о программе</button>)raw"); 



  { sets::Group r(b);
    if (b.Switch("Время", &timer))  b.reload();
    if (timer) b.Time("установить", &timer_time);
    if (timer) {
      sets::Row g(b);
      if (b.Time("начало", &start_mute)) ;
      if (b.Time("конец", &end_mute)) ;
    }
  }

  // Расширенные Настройки
  { sets::Group r(b, "");
    if (b.Switch("РАСШИРЕННЫЕ НАСТРОЙКИ", &show_setting)) b.reload();

    if (show_setting) {
      if (b.Slider("слайдер", 1, 10000, 1, ""));
      if (b.Switch("Switch"));
      if (b.Slider("яркость", 0, 255, 1, "", &dimm));
      b.HTML("", "<span class=\"HR\"></span>");

    }
  }

  // логгер
  if (show_setting) {
    sets::Group r(b, "ЛОГГЕР");
    b.Log(logger);
    {
      sets::Buttons r(b);
      if (b.Button("Очистить"))  //
      {
        logger.clear();
        b.reload();
      }

      if (b.Button("Инфо")) {
        static uint8_t count_ = 0;
        count_++;


        logger.print( "------------ STATUS ");
        logger.print(count_);
        logger.println( " ------------");
        logger.print("wifi RSSI: ");
        logger.println(WiFi.RSSI());
        // Вывод информации о памяти
        logger.println( "--- оперативная память ---");
        logger.println( "Свободная куча: " + (String)ESP.getFreeHeap() + " байт");

#if ESP32_SDP_OTA
        logger.println( "Общий размер кучи: " + (String)ESP.getHeapSize() + " байт");
        logger.println( "Минимальная свободная куча: " + (String)ESP.getMinFreeHeap() + " байт");
#elif ESP32_SDP
        logger.println( "Общий размер кучи: " + (String)ESP.getHeapSize() + " байт");
        logger.println( "Минимальная свободная куча: " + (String)ESP.getMinFreeHeap() + " байт");
#else

#endif



        //  logger.println( "Максимальный блок кучи (Max Alloc Heap): ", ESP.getMaxAllocHeap(), " байт");
        logger.println( "--- флеш память ---");
        logger.println( "Общий размер флэш-памяти : " + (String)ESP.getFlashChipSize() + " байт");
        logger.println( "Размер скетча : " + (String)ESP.getSketchSize() + " байт");
        logger.println( "Свободное место для скетча: " + (String)ESP.getFreeSketchSpace() + " байт");
        logger.println( "Частота флэш-памяти (Flash Chip Speed): " + (String)ESP.getFlashChipSpeed() + " Гц");
        logger.print( "Режим флэш-памяти (Flash Chip Mode): ") ;
        logger.print(ESP.getFlashChipMode() == FM_QIO ? "QIO" : ESP.getFlashChipMode() == FM_QOUT ? "QOUT"
                     : ESP.getFlashChipMode() == FM_DIO    ? "DIO"
                     : ESP.getFlashChipMode() == FM_DOUT   ? "DOUT"
                     : "UNKNOWN");

        logger.println( "--- внешняя память ---");
        // Вывод информации о PSRAM (если поддерживается)
#ifdef CONFIG_SPIRAM_SUPPORT
        logger.println( "Общий размер PSRAM (PSRAM Size): " + (String)ESP.getPsramSize() + " байт");
        logger.println( "Свободный PSRAM (Free PSRAM): " + (String)ESP.getFreePsram() + " байт");
#else
        logger.println( "PSRAM: Не поддерживается на этом модуле");
#endif

        logger.println( "--- процессор ---");
        // Вывод информации о процессоре
        logger.println( "Частота процессора: " + (String)ESP.getCpuFreqMHz() + " МГц");
#if ESP32_SDP_OTA
        logger.println( "Количество ядер: " + (String)ESP.getChipCores());
        logger.println( "Модель чипа: " + (String)ESP.getChipModel());
        logger.println( "Ревизия чипа: " + (String)ESP.getChipRevision());
#elif ESP32_SDP
        logger.println( "Количество ядер: " + (String)ESP.getChipCores());
        logger.println( "Модель чипа: " + (String)ESP.getChipModel());
        logger.println( "Ревизия чипа: " + (String)ESP.getChipRevision());
#else

#endif



        logger.println( "Версия SDK: " + (String)ESP.getSdkVersion());

        b.reload();
      }

    }

  }

  if (show_setting) {
    sets::Group r(b, "WIFI");
    if (b.Input("имя", AnyPtr(ssid, 25)));
    if (b.Pass("пароль", AnyPtr(password, 20)));
  }

  {
    sets::Buttons r(b);
    if (b.Button("Перезагрузить", 0xEB5453)) ESP.restart();

    if (b.Button("Обновить"))  b.reload();

  }

  { sets::Row r(b);
    if (connected) b.Label(F(""), "хороший статус", 0x02b314);
    else b.Label(F(""), "плохой статус", sets::Colors::Red);

    if (!connected) {
      if (b.Button(F("клац"))) {
        connected = !connected;
        b.reload();
      }
    }
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println();

  // ======== WIFI ========
  WiFi.mode(WIFI_AP_STA);
  if(app)  WiFi.mode(WIFI_AP_STA);
  else     WiFi.mode(WIFI_STA);

  WiFi.begin(ssid, password);
  uint8_t tries = 20;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (!--tries) break;
  }
  Serial.println();
  if(WiFi.status() == WL_CONNECTED) {
      Serial.print("WIFI Connected: ");
  Serial.println(WiFi.localIP());
  }
  else {
    Serial.print("WIFI Connect error!");
  }


  // ======== SETTINGS ========
  sett.begin();
  sett.onBuild(build);


}

void loop() {
  static unsigned long prev = 0;
  static bool prevConn = false;
  
  if (millis() - prev >= 5000) {
    prev = millis();
    connected = false;
    
    if (connected != prevConn) {
      sett.reload();
      prevConn = connected;
    }
  }

  sett.tick();
}
